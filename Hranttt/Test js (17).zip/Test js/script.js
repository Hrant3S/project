// var user1 = [
//   Math.floor(Math.random() * 91),
//   Math.floor(Math.random() * 91),
//   Math.floor(Math.random() * 91),
//   Math.floor(Math.random() * 91),
//   Math.floor(Math.random() * 91)
// ];
// var user2 = [
//   Math.floor(Math.random() * 91),
//   Math.floor(Math.random() * 91),
//   Math.floor(Math.random() * 91),
//   Math.floor(Math.random() * 91),
//   Math.floor(Math.random() * 91)
// ];
// var arr = [];
// for (var i = 0; i < 91; i++) {
//   arr.push(i);
// }
//
// var num = arr.length;
//
// for (var i = 0; i < 90; i++) {
//   var index = Math.floor(Math.random() * num);
//   if (user1.indexOf(arr[index]) != -1) {
//     user1.splice(user1.indexOf(arr[index]), 1)
//   }
//   if (user2.indexOf(arr[index]) != -1) {
//     user2.splice(user2.indexOf(arr[index]), 1)
//   }
//   if (isEmpty()) {
//     break;
//   }
//   arr.splice(index, 1);
//   --num;
// }
//
// function isEmpty() {
//   if (user1.length === 0) {
//     console.log('User 1 is win');
//     return true;
//   }
//   if (user2.length === 0) {
//     console.log('User 2 is win');
//     return true;
//   }
// }
//
//
// // var arr = [
// //   {name: 'Mike', age: 25},
// //   {name: 'John', age: 45},
// //   {name: 'Poxos', age: 12}
// // ];
// //
// // var obj = arr.find(function(item, i, arr) {
// //   return item.name === 'dfsgsdJohn';
// // });
// // console.log(obj);

// var arr = [
//   {name: 'Mike', age: 25},
//   {name: 'John', age: 45},
//   {name: 'Poxos', age: 12}
// ];


// var arr = [78, 45, 36, 12, 96];
//
// var x = arr.every(function(item, i) {
//   return item < 100;
// })
//
// console.log(x);

// var arr = [78, 45, 36, 12, 96];
// console.log(arr[0]);
// console.log(arr.at(0));
// console.log(arr.at(-1));

// var str = 'Hello world!';
//
//
// console.log(str.length);
// console.log(str[4]);

// Math.PI
// Math.E
// Math.SQRT2


// console.log(2 * Math.PI * 13.5);
// console.log(Math.PI * Math.pow(9, 2));

// var obj = {
//   name: 'Mike'
// };
//
// delete obj.name
//
// console.log('name' in obj);


var str = 'Hello World!';


// console.log(str.length);
// console.log(str[4]);
// console.log(str.concat(' test', ' test1', 'Mike'));
// console.log(str.toLowerCase());
// console.log(str.toUpperCase());
// console.log(str.charAt(1));
// console.log(str.charAt(-1));
// console.log(str.at(-1));

// var str = 'hello world!'; // 'Hello World!'
// console.log(str.charCodeAt(1));
//
// var str = 'HELLo world!'; // 'hellO WORLD'
// console.log(String.fromCharCode(101));
// console.log(String.fromCharCode(1));

// var str = 'hello world!';
// console.log(str.slice(1));
// console.log(str.slice(1, 5));
// console.log(str.slice(1, 5));
// console.log(str.slice(5, 1));
// console.log(str.slice(-6, -3));
// console.log(str.substring(3));
// console.log(str.substring(3, 6));
// console.log(str.substring(6, 3));
// console.log(str.substring(-6, -3));



var str = 'hello world!';
// console.log(str.indexOf('l'));
// console.log(str.indexOf('A'));
// console.log(str.indexOf('l', 4));
// console.log(str.indexOf('world'));
// console.log(str.indexOf('hello world'));
// console.log(str.indexOf('rld'));

// console.log(str.lastIndexOf('l'));
// console.log(str.lastIndexOf('l', 4));

// var str = 'hello world!';
//
// console.log(str.replace('e', '45'));
// console.log(str.replace('l', '45'));
// console.log(str.replaceAll('l', '45'));

// var str = '   hello world!   ';
// console.log(str.length);
// console.log(str.trim());
// console.log(str.trim().length);
// console.log(str.trimLeft());
// console.log(str.trimRight());

// var str = 'hello world!';
// console.log(str.split(' '));
// console.log(str.split('e'));
// console.log(str.split('l'));
// console.log(str.split('l', 2));
// console.log(str.split(''));

// var str = 'hello world!';
// console.log(str.includes(' '));
// console.log(str.startsWith('H'));
// console.log(str.startsWith('hello'));
// console.log(str.endsWith('!'));
// console.log(str.endsWith('world!'));

// var str = 'hello world!';
// console.log(str.bold());
// console.log(str.sub());
// console.log(str.sup());
// console.log(str.small());

// var num = 12;
//
// console.log(num.toString());
// console.log(num.toFixed(2));
//
// var num1 = 45.4564987432;
// console.log(num1.toFixed(3));
// console.log(num1.toPrecision(1));
// console.log(num1.toExponential());


// var bool = true;
// console.log(bool.toString());
